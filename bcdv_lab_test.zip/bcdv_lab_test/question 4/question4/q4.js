const moment = require('moment')
const events = require('events');
var eventEmit = new events.EventEmitter;

const currentTimeCallback = () => {
    var wrapped = moment(new Date());
    console.log(`Current Time: ${wrapped.format('hh:mm:ss a')}`);
  }
  
eventEmit.on('currentTime',currentTimeCallback)
  
eventEmit.emit('currentTime');
