const userInfo = require('./module/systemInfo');

userInfo.systeminfo();
userInfo.userinfo();