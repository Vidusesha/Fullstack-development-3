const os = require('os')

module.exports = {
    systeminfo: function() {console.log(`Operating System Info: CPU architecture: ${os.arch} Host name: ${os.hostname} OS name: ${os.type}`)},

    userinfo: function() {console.log(`User Info: User name: ${os.userInfo().username} dir: ${os.homedir}`)},
}