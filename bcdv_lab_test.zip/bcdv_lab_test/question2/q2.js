const mixedArray = ['Matrix' , 1 , true , 2 , false , 3]

var multiplyNumbers = (arr) => {
    let result1 = arr.filter(value => typeof value === 'number')
    let finalResult = result1.map(x => x * 5)

    console.log(finalResult)
}

multiplyNumbers(mixedArray);