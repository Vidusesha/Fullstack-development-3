const say = require("say");

say.speak('Hello!');

say.stop()

say.speak("I'm sorry , Dave", 'Good News', 1.0, (err) => {
    if (err) {
      return console.error(err)
    }
   
    console.log('Text has been spoken.')
  });

  let delay = 5000;

  setTimeout(function () {

    say.speak("Hello, Alex", 'Good News', 1.0, (err) => {
        if (err) {
          return console.error(err)
        }
       
        console.log('Text has been spoken.')
      });
  
  }, delay);

//say.speak("Hello?" , 'Alex' , 0.5)

//say.stop()